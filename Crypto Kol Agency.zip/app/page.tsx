import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Globe2, Users, TrendingUp, Zap, MessageSquare, Video, Send, Music2, Instagram } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/40 backdrop-blur-sm sticky top-0 z-50 bg-background/80">
        <div className="container mx-auto px-4 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">KOL Network</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#network" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Network
            </a>
            <a href="#platforms" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Platforms
            </a>
            <a href="#narratives" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Narratives
            </a>
            <a href="#contact" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Contact
            </a>
          </nav>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Get Started</Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 lg:px-8 py-20 lg:py-32">
        <div className="max-w-5xl mx-auto text-center space-y-8">
          <Badge variant="secondary" className="text-sm px-4 py-1.5">
            <TrendingUp className="w-3 h-3 mr-2 inline" />
            Trusted by Leading Crypto Projects
          </Badge>
          <h1 className="text-5xl lg:text-7xl font-bold tracking-tight text-balance">
            Your Gateway to <span className="text-primary">1,500+</span> Global Crypto Influencers
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-balance leading-relaxed">
            Connect with the world's most influential voices in crypto. From DeFi to memecoins, we've built the largest
            verified network of KOLs across every platform and narrative.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 text-base px-8">
              Book a Campaign
            </Button>
            <Button size="lg" variant="outline" className="text-base px-8 bg-transparent">
              View Network
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section id="network" className="container mx-auto px-4 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="p-8 bg-card border-border/40 hover:border-primary/50 transition-colors">
            <div className="space-y-2">
              <Users className="w-8 h-8 text-primary" />
              <div className="text-4xl font-bold">1,500+</div>
              <div className="text-muted-foreground">Verified Influencers</div>
            </div>
          </Card>
          <Card className="p-8 bg-card border-border/40 hover:border-primary/50 transition-colors">
            <div className="space-y-2">
              <Globe2 className="w-8 h-8 text-primary" />
              <div className="text-4xl font-bold">4</div>
              <div className="text-muted-foreground">Global Regions</div>
            </div>
          </Card>
          <Card className="p-8 bg-card border-border/40 hover:border-primary/50 transition-colors">
            <div className="space-y-2">
              <MessageSquare className="w-8 h-8 text-primary" />
              <div className="text-4xl font-bold">5</div>
              <div className="text-muted-foreground">Social Platforms</div>
            </div>
          </Card>
          <Card className="p-8 bg-card border-border/40 hover:border-primary/50 transition-colors">
            <div className="space-y-2">
              <TrendingUp className="w-8 h-8 text-primary" />
              <div className="text-4xl font-bold">100M+</div>
              <div className="text-muted-foreground">Combined Reach</div>
            </div>
          </Card>
        </div>
      </section>

      {/* Global Reach Section */}
      <section className="container mx-auto px-4 lg:px-8 py-20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-4xl lg:text-5xl font-bold text-balance">Global Network, Local Expertise</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
              Our influencers span every major crypto market worldwide
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { region: "North America", count: "450+", flag: "🇺🇸" },
              { region: "Europe", count: "400+", flag: "🇪🇺" },
              { region: "CIS Region", count: "350+", flag: "🌍" },
              { region: "Asia Pacific", count: "300+", flag: "🌏" },
            ].map((region) => (
              <Card
                key={region.region}
                className="p-6 bg-card border-border/40 text-center hover:border-primary/50 transition-colors"
              >
                <div className="text-5xl mb-4">{region.flag}</div>
                <div className="text-2xl font-bold mb-2">{region.count}</div>
                <div className="text-muted-foreground">{region.region}</div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Platforms Section */}
      <section id="platforms" className="container mx-auto px-4 lg:px-8 py-20 bg-secondary/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-4xl lg:text-5xl font-bold text-balance">Every Platform That Matters</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
              Reach your audience wherever they are
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[
              { name: "X (Twitter)", icon: MessageSquare, color: "text-blue-400" },
              { name: "YouTube", icon: Video, color: "text-red-500" },
              { name: "Telegram", icon: Send, color: "text-cyan-400" },
              { name: "TikTok", icon: Music2, color: "text-pink-500" },
              { name: "Instagram", icon: Instagram, color: "text-purple-500" },
            ].map((platform) => (
              <Card
                key={platform.name}
                className="p-6 bg-card border-border/40 hover:border-primary/50 transition-all hover:scale-105"
              >
                <div className="flex flex-col items-center gap-3 text-center">
                  <platform.icon className={`w-10 h-10 ${platform.color}`} />
                  <div className="font-semibold text-sm">{platform.name}</div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Narratives Section */}
      <section id="narratives" className="container mx-auto px-4 lg:px-8 py-20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-4xl lg:text-5xl font-bold text-balance">Specialized by Narrative</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
              Expert influencers for every crypto vertical
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { name: "General Crypto", desc: "Broad market coverage and news", count: "300+" },
              { name: "DeFi", desc: "Decentralized finance experts", count: "250+" },
              { name: "Memecoins", desc: "Viral content specialists", count: "200+" },
              { name: "NFTs", desc: "Digital art and collectibles", count: "180+" },
              { name: "Play2Earn", desc: "Gaming and metaverse", count: "150+" },
              { name: "Trading", desc: "Technical analysis pros", count: "220+" },
            ].map((narrative) => (
              <Card
                key={narrative.name}
                className="p-6 bg-card border-border/40 hover:border-primary/50 transition-colors group"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold group-hover:text-primary transition-colors">{narrative.name}</h3>
                    <Badge variant="secondary">{narrative.count}</Badge>
                  </div>
                  <p className="text-muted-foreground text-sm">{narrative.desc}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="container mx-auto px-4 lg:px-8 py-20">
        <Card className="max-w-4xl mx-auto p-12 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <div className="text-center space-y-6">
            <h2 className="text-4xl lg:text-5xl font-bold text-balance">Ready to Amplify Your Project?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
              Let's connect you with the perfect influencers to reach your target audience and drive real results.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 text-base px-8">
                Schedule a Call
              </Button>
              <Button size="lg" variant="outline" className="text-base px-8 bg-transparent">
                View Case Studies
              </Button>
            </div>
          </div>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 mt-20">
        <div className="container mx-auto px-4 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold">KOL Network</span>
              </div>
              <p className="text-sm text-muted-foreground">The world's largest crypto influencer network</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Campaign Management
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Influencer Matching
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Analytics & Reporting
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Case Studies
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Twitter
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Telegram
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    LinkedIn
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/40 mt-12 pt-8 text-center text-sm text-muted-foreground">
            <p>© 2025 KOL Network. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
